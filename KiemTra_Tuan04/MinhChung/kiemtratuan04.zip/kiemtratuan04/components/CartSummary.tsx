

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 16,
    textAlign: "center",
  },
  item: {
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "black",
    borderRadius: 8,
  },
  name: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 4,
  },
  price: {
    fontSize: 14,
    color: "green",
    marginBottom: 8,
  },
  cartInfo: {
    marginBottom: 16,
    padding: 12,
    borderWidth: 1,
    borderRadius: 8,
    borderColor: "black"
  },
  cartText: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 4,
  }
});

export default App;

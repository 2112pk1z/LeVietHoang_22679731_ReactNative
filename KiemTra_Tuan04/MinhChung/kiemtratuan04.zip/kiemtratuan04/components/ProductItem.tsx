import React, {useState} from 'react';
import {
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  FlatList,
  Button,
} from 'react-native';

interface ProductItemProps {
  product: {id: string; name: string; price: number};
  onAddtoCart: (product: any) => void;
}

const ProductItem: React.FC<ProductItemProps> = ({product, onAddToCart}) => {
  return (
    <View style = {styles.item}>
      <Text style = {styles.name}>{product.name}</Text>
      <Text style = {styles.price}>{product.price} đ</Text>
      <Button title="Thêm vào giỏ" onPress={() => onAddToCart(product)} />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 16,
    textAlign: "center",
  },
  item: {
    padding: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "black",
    borderRadius: 8,
  },
  name: {
    fontSize: 16,
    fontWeight: "bold",
    marginBottom: 4,
  },
  price: {
    fontSize: 14,
    color: "green",
    marginBottom: 8,
  },
  cartInfo: {
    marginBottom: 16,
    padding: 12,
    borderWidth: 1,
    borderRadius: 8,
    borderColor: "black"
  },
  cartText: {
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 4,
  }
});

export default App;
